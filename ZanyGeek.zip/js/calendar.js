var today = new Date();
function Last() {
    today = new Date(today.getFullYear(), today.getMonth() - 1, today.getDate());

    full();
}
function Next() {
    today = new Date(today.getFullYear(), today.getMonth() + 1, today.getDate());

    full();
}
function full() {
    var first = new Date(today.getFullYear(), today.getMonth(), 1);
    var last = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    var td = document.querySelector(".dal");
    var month = document.getElementById("Month");
    var year = document.getElementById("year");
    year.innerText = today.getFullYear();
    if (today.getMonth() == 0) { month.innerText = "January"; document.body.style.backgroundImage = "url('icon/calendar/1.png')"; document.body.style.backgroundSize = "100% 100%" }
    else if (today.getMonth() == 1) { month.innerText = "February"; document.body.style.backgroundImage = "url('icon/calendar/2.png')"; document.body.style.backgroundSize = "100% 100%" }
    else if (today.getMonth() == 2) { month.innerText = "March"; document.body.style.backgroundImage = "url('icon/calendar/3.png')"; document.body.style.backgroundSize = "100% 100%" }
    else if (today.getMonth() == 3) { month.innerText = "April"; document.body.style.backgroundImage = "url('icon/calendar/4.png')"; document.body.style.backgroundSize = "100% 100%" }
    else if (today.getMonth() == 4) { month.innerText = "May"; document.body.style.backgroundImage = "url('icon/calendar/5.png')"; document.body.style.backgroundSize = "100% 100%" }
    else if (today.getMonth() == 5) { month.innerText = "June"; document.body.style.backgroundImage = "url('icon/calendar/6.png')"; document.body.style.backgroundSize = "100% 100%" }
    else if (today.getMonth() == 6) { month.innerText = "July"; document.body.style.backgroundImage = "url('icon/calendar/7.png')"; document.body.style.backgroundSize = "100% 100%" }
    else if (today.getMonth() == 7) { month.innerText = "August"; document.body.style.backgroundImage = "url('icon/calendar/8.png')"; document.body.style.backgroundSize = "100% 100%" }
    else if (today.getMonth() == 8) { month.innerText = "September"; document.body.style.backgroundImage = "url('icon/calendar/9.png')"; document.body.style.backgroundSize = "100% 100%" }
    else if (today.getMonth() == 9) { month.innerText = "October"; document.body.style.backgroundImage = "url('icon/calendar/10.png')"; document.body.style.backgroundSize = "100% 100%" }
    else if (today.getMonth() == 10) { month.innerText = "November"; document.body.style.backgroundImage = "url('icon/calendar/11.png')"; document.body.style.backgroundSize = "100% 100%" }
    else if (today.getMonth() == 11) { month.innerText = "December"; document.body.style.backgroundImage = "url('icon/calendar/12.png')"; document.body.style.backgroundSize = "100% 100%" }

    while (td.rows.length > 3) {
        td.deleteRow(td.rows.length - 1);
    }
    var row = td.insertRow();
    var day = 0;


    for (i = 0; i < first.getDay(); i++) {
        cell = row.insertCell();
        day += 1;
    } //i가 첫째날의 요일의 값보다 작으면 ++ 반복 (첫째날 칸전까지 cell 만들기)

    for (i = 1; i <= last.getDate(); i++) {
        cell = row.insertCell();
        cell.innerText = i;
        day += 1;
        if (day % 7 == 0) {
            row = td.insertRow();
        }
    }
}